

let alo = 50
let potol = 150
let mula = 80
let gajor = 200
let kodo = 90
let sim = 145
let total = alo + potol + mula + gajor + kodo + sim

console.log(`
            alor dam = ${alo}
            alor dam = ${potol}
            alor dam = ${mula}
            alor dam = ${gajor}
            alor dam = ${kodo}
            alor dam = ${sim}
            -----------------------
            total   = ${ total }
`);