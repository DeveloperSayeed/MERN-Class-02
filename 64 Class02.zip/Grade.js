


let result = prompt("number");

if ( result >= 0 && result <= 32){
    console.log("sorry you faild exam");
}

else if(result > 32 && result <= 39){
    console.log("You got GPA C");
}

else if(result >= 40 && result <= 49){
    console.log("You got GPA D");
}
else if(result >= 50 && result <= 59){
    console.log("You got GPA B");
}
else if(result >= 60 && result <= 69){
    console.log("You got GPA A-");
}
else if(result >= 70 && result <= 79){
    console.log("You got GPA A");
}
else if(result >= 80 && result <= 100){
    console.log("You got GPA A");
}
else{" Plase give your right information"}
