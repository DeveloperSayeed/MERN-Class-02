

const currency = prompt("Currency Name");
const amount = prompt(" Amount");




if ( currency == "dollar"){
    console.log(` ${currency} ${amount} = ${amount * 86} taka`)}

else if( currency == "pound"){
    console.log(` ${currency} ${amount} = ${amount * 90} taka`)
}
else if( currency == "rupe"){
    console.log(` ${currency} ${amount} = ${amount * .80} taka`)
}
else if( currency == "real"){
    console.log(` ${currency} ${amount} = ${amount * 22.60} taka`)
}
else if( currency == "real"){
    console.log(` ${currency} ${amount} = ${amount * 22.60} taka`)
}
else if( currency == "ringit"){
    console.log(` ${currency} ${amount} = ${amount * 24} taka`)
}

else if( currency == "diram"){
    console.log(` ${currency} ${amount} = ${amount *324} taka`)
}


